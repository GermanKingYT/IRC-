#!/usr/bin/env perl

system './build.pl rakudo-moar';
system './build.pl rakudo-jvm';
