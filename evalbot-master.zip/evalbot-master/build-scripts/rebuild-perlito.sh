#!/bin/bash
cd ~/Perlito
git pull
