# heavyaidra
IRC-based mass router scanner/exploiter using SSH and kaiten.
<h2>FAQ</h2>
<h3>Why?</h3>
<p>Because lightaidra didn't work well, ddos & spreading was broken, additionally it would never re-connect after pinging out. Kaiten is responsible for the stable bot in heavyaidra, and the scanner I work spreads flawlessy.</p>
<h3>How do I set this up?</h3>
Read </i>heavyhidra.py</i>
<h3>I'm not a programmer. Did you add errors to prevent non-programmers from using it?</h3>
Nope. Feel free to do your own independent research this project!
<h3>How can I donate money to this project?</h3>
With Bitcoin: <i>13rddMd7ErFQYsjYPfYAnqxmPzZxQPrVyo</i>
