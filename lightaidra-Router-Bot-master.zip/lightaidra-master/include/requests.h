#ifndef __REQUESTS_H_
#define __REQUESTS_H_

int login_status, stop;
int random_ct, random_num;
char *token, status_temp[128], nt[3];

#endif
